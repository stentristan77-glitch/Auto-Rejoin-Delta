package com.beemacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MacroService : AccessibilityService() {

    companion object {
        @Volatile var instance: MacroService? = null
    }

    val main = Handler(Looper.getMainLooper())
    lateinit var store: Store
    private lateinit var wm: WindowManager

    @Volatile var foregroundPkg: String = ""

    private var panel: View? = null
    private var statusText: TextView? = null
    private var startBtn: Button? = null
    private var setupView: View? = null

    private var engine: Engine? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        store = Store(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            // Ignore our own overlays and the system UI (notification shade etc.)
            if (pkg != packageName && pkg != "com.android.systemui") foregroundPkg = pkg
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        engine?.stop()
        removeView(panel); removeView(setupView)
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- screen helpers

    fun screenSize(): Point {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                Point(b.width(), b.height())
            } else {
                val p = Point()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealSize(p)
                p
            }
        } catch (e: Exception) {
            val m = resources.displayMetrics
            Point(m.widthPixels, m.heightPixels)
        }
    }

    fun setStatus(text: String) {
        main.post { statusText?.text = text }
    }

    fun setRunningUi(running: Boolean) {
        main.post { startBtn?.text = if (running) "■ Stop" else "▶ Start" }
    }

    /** Sends a gesture and waits until it has finished (or failed). */
    fun gesture(g: GestureDescription, timeoutMs: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, main)
        if (!sent) return false
        latch.await(timeoutMs + 2000, TimeUnit.MILLISECONDS)
        return ok
    }

    /** Takes a screenshot (Android 11+). Returns null if not possible. */
    fun screenshot(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = screenshot.hardwareBuffer
                        val wrapped = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                        result = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                        wrapped?.recycle()
                        hb.close()
                    } catch (e: Exception) { }
                    latch.countDown()
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
        } catch (e: Exception) {
            return null
        }
        latch.await(3, TimeUnit.SECONDS)
        return result
    }

    /** How full the pollen bar is (0..1), or null if it can't be read. */
    fun pollenFraction(): Float? {
        val bmp = screenshot() ?: return null
        try {
            val size = screenSize()
            val sx = bmp.width.toFloat() / size.x
            val sy = bmp.height.toFloat() / size.y
            val l = store.point("BAR_L"); val r = store.point("BAR_R")
            val n = 80
            var last = -1
            for (i in 0..n) {
                val fx = l.x + (r.x - l.x) * i / n
                val fy = l.y + (r.y - l.y) * i / n
                val x = (fx * size.x * sx).toInt().coerceIn(0, bmp.width - 1)
                val y = (fy * size.y * sy).toInt().coerceIn(0, bmp.height - 1)
                val c = bmp.getPixel(x, y)
                val rr = Color.red(c); val gg = Color.green(c); val bb = Color.blue(c)
                val sat = maxOf(rr, gg, bb) - minOf(rr, gg, bb)
                // The empty part of the bar is grey and the numbers are white (low colour).
                // The filled part is strongly coloured (green, or another colour when full).
                if (sat > 70) last = i
            }
            return (last + 1).toFloat() / (n + 1)
        } finally {
            bmp.recycle()
        }
    }

    // ---------------------------------------------------------------- floating panel

    private fun overlayParams(w: Int, h: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
    }

    private fun removeView(v: View?) {
        try { if (v != null) wm.removeView(v) } catch (e: Exception) { }
    }

    private fun roundBg(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun smallButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 11f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = roundBg(Color.rgb(38, 66, 112), 12f)
        setPadding(8, 4, 8, 4)
        minHeight = 0; minimumHeight = 0
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Color.argb(225, 24, 26, 33), 18f)
            setPadding(10, 8, 10, 10)
        }
        val title = TextView(this).apply {
            text = "🐝 Bee Macro  ✥"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(4, 4, 4, 8)
        }
        box.addView(title)

        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(dp(130), dp(34))
            lp.topMargin = dp(4)
            box.addView(v, lp)
        }

        startBtn = smallButton("▶ Start") { toggleRun() }
        add(startBtn!!)
        add(smallButton("Test route") { runTestRoute() })
        add(smallButton("Bar %") {
            Thread {
                val f = pollenFraction()
                setStatus(if (f == null) "Can't read screen (needs Android 11+)" else "Pollen bar: ${(f * 100).toInt()}%")
            }.start()
        })
        add(smallButton("Setup markers") { showSetup() })

        statusText = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.rgb(190, 196, 210))
            textSize = 10f
            maxWidth = dp(130)
            setPadding(4, 8, 4, 0)
        }
        box.addView(statusText)

        val params = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(8)
        params.y = dp(120)

        // Drag the panel by its title
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - downX).toInt()
                    params.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, params) } catch (ex: Exception) { }
                }
            }
            true
        }

        panel = box
        try { wm.addView(box, params) } catch (e: Exception) { }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- run / stop

    private fun toggleRun() {
        val e = engine
        if (e != null && e.running) {
            e.stop()
            setStatus("Stopping...")
        } else {
            engine = Engine(this).also { it.start(testRouteOnly = false) }
        }
    }

    private fun runTestRoute() {
        if (engine?.running == true) { setStatus("Stop the macro first"); return }
        engine = Engine(this).also { it.start(testRouteOnly = true) }
    }

    // ---------------------------------------------------------------- setup markers

    private fun showSetup() {
        if (engine?.running == true) { setStatus("Stop the macro first"); return }
        removeView(setupView)
        val size = screenSize()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.argb(60, 0, 0, 0)) }
        val markers = HashMap<String, TextView>()
        val half = dp(22)

        for ((id, info) in Store.MARKERS) {
            val p = store.point(id)
            val dot = TextView(this).apply {
                text = info.first
                textSize = 9f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(170, 220, 40, 40))
                    setStroke(3, Color.WHITE)
                }
            }
            val lp = FrameLayout.LayoutParams(half * 2, half * 2)
            root.addView(dot, lp)
            dot.x = p.x * size.x - half
            dot.y = p.y * size.y - half

            var offX = 0f; var offY = 0f
            dot.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { offX = e.rawX - v.x; offY = e.rawY - v.y }
                    MotionEvent.ACTION_MOVE -> { v.x = e.rawX - offX; v.y = e.rawY - offY }
                }
                true
            }
            markers[id] = dot
        }

        val help = TextView(this).apply {
            text = "Drag each red dot onto its button (centre of the dot = where it taps).\n" +
                "Pollen bar: put LEFT on the left edge of the green fill, RIGHT on the right end of the bar."
            setTextColor(Color.WHITE)
            textSize = 11f
            background = roundBg(Color.argb(200, 24, 26, 33), 12f)
            setPadding(16, 10, 16, 10)
        }
        val helpLp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        helpLp.gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        helpLp.bottomMargin = dp(70)
        root.addView(help, helpLp)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = smallButton("✔ Save") {
            for ((id, v) in markers) {
                store.setPoint(id, (v.x + half) / size.x, (v.y + half) / size.y)
            }
            removeView(setupView); setupView = null
            setStatus("Markers saved")
        }
        val reset = smallButton("Reset") {
            store.resetPoints()
            removeView(setupView); setupView = null
            showSetup()
        }
        val cancel = smallButton("✕ Cancel") { removeView(setupView); setupView = null }
        for (b in listOf(save, reset, cancel)) {
            val lp = LinearLayout.LayoutParams(dp(90), dp(38)); lp.leftMargin = dp(6)
            buttons.addView(b, lp)
        }
        val bLp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        bLp.gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        bLp.bottomMargin = dp(16)
        root.addView(buttons, bLp)

        val params = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        setupView = root
        try { wm.addView(root, params) } catch (e: Exception) { setStatus("Couldn't open setup") }
    }
}
