package com.beemacro

import android.content.Context
import android.graphics.PointF

/** Everything the macro remembers: marker positions (as 0..1 fractions of the screen) and settings. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("beemacro", Context.MODE_PRIVATE)

    companion object {
        /** Marker id -> label shown in setup + default position (from a 2412x1080 screenshot). */
        val MARKERS = linkedMapOf(
            "JOY" to Triple("Joystick", 275f / 2412f, 915f / 1080f),
            "JUMP" to Triple("Jump", 2135f / 2412f, 915f / 1080f),
            "MENU" to Triple("Menu (Roblox logo)", 210f / 2412f, 100f / 1080f),
            "RESPAWN" to Triple("Respawn (menu)", 1205f / 2412f, 450f / 1080f),
            "CONFIRM" to Triple("Respawn (confirm)", 875f / 2412f, 762f / 1080f),
            "ACTION" to Triple("Tap button (Make Honey / Cannon)", 935f / 2412f, 240f / 1080f),
            "BAR_L" to Triple("Pollen bar LEFT end", 1322f / 2412f, 100f / 1080f),
            "BAR_R" to Triple("Pollen bar RIGHT end", 1728f / 2412f, 100f / 1080f),
        )

        const val DEFAULT_ROUTE = """# Hive -> Red Cannon -> Pine Tree  (NEEDS TUNING!)
# move <angle> <seconds>   angle: 0=forward 90=right 180=back 270=left
# glide <angle> <seconds>  = tap jump (opens glider in the air) while moving
# jump | action | wait <seconds>
move 180 1.5
move 270 4
move 0 3
action
wait 1.5
glide 0 5
wait 2"""
    }

    fun point(id: String): PointF {
        val d = MARKERS[id]!!
        return PointF(sp.getFloat("${id}_x", d.second), sp.getFloat("${id}_y", d.third))
    }

    fun setPoint(id: String, fx: Float, fy: Float) {
        sp.edit().putFloat("${id}_x", fx).putFloat("${id}_y", fy).apply()
    }

    fun resetPoints() {
        val e = sp.edit()
        MARKERS.keys.forEach { e.remove("${it}_x"); e.remove("${it}_y") }
        e.apply()
    }

    var robloxPkg: String
        get() = sp.getString("pkg", "com.roblox.client") ?: "com.roblox.client"
        set(v) = sp.edit().putString("pkg", v).apply()

    var hiveSlot: Int
        get() = sp.getInt("slot", 1)
        set(v) = sp.edit().putInt("slot", v).apply()

    fun route(slot: Int = hiveSlot): String = sp.getString("route_$slot", DEFAULT_ROUTE) ?: DEFAULT_ROUTE
    fun setRoute(slot: Int, text: String) = sp.edit().putString("route_$slot", text).apply()

    var bagFullPct: Int
        get() = sp.getInt("bagfull", 95)
        set(v) = sp.edit().putInt("bagfull", v).apply()

    var maxFarmMin: Int
        get() = sp.getInt("maxfarm", 15)
        set(v) = sp.edit().putInt("maxfarm", v).apply()

    var maxConvertMin: Int
        get() = sp.getInt("maxconv", 8)
        set(v) = sp.edit().putInt("maxconv", v).apply()

    /** Zigzag farm pattern: seconds forward/back and seconds sideways per leg. */
    var patternLong: Float
        get() = sp.getFloat("plong", 2.0f)
        set(v) = sp.edit().putFloat("plong", v).apply()

    var patternSide: Float
        get() = sp.getFloat("pside", 0.6f)
        set(v) = sp.edit().putFloat("pside", v).apply()

    /** Joystick push distance, as a fraction of the screen height. */
    var joyRadius: Float
        get() = sp.getFloat("joyr", 0.10f)
        set(v) = sp.edit().putFloat("joyr", v).apply()
}
