package com.beemacro

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var status: TextView
    private lateinit var slotLabel: TextView
    private lateinit var routeInput: EditText
    private var slot = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        slot = store.hiveSlot

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 56, 48, 48)
        }

        fun label(text: String, size: Float = 14f) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 28, 0, 6)
        }.also { root.addView(it) }

        fun field(value: String, number: Boolean = false, decimal: Boolean = false) = EditText(this).apply {
            setText(value)
            inputType = when {
                decimal -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                number -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT
            }
            setSingleLine()
        }.also { root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
        }.also { root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }

        label("🐝 Bee Macro", 26f)

        label("Step 1 - turn on the macro")
        button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        TextView(this).apply {
            text = "Find \"Bee Macro\" there and turn it on. If it's greyed out: Settings → Apps → Bee Macro → ⋮ (top right) → Allow restricted settings, then try again."
            textSize = 12f
        }.also { root.addView(it) }

        label("Hive slot")
        val slotRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val minus = Button(this).apply { text = "−" }
        slotLabel = TextView(this).apply { textSize = 20f; setPadding(40, 0, 40, 0) }
        val plus = Button(this).apply { text = "+" }
        slotRow.addView(minus); slotRow.addView(slotLabel); slotRow.addView(plus)
        root.addView(slotRow)

        label("Route from hive to field (for this hive slot)")
        routeInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(false)
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            textSize = 13f
            typeface = android.graphics.Typeface.MONOSPACE
        }
        root.addView(routeInput, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        fun showSlot() {
            slotLabel.text = "Slot $slot"
            routeInput.setText(store.route(slot))
        }
        minus.setOnClickListener { store.setRoute(slot, routeInput.text.toString()); if (slot > 1) slot--; showSlot() }
        plus.setOnClickListener { store.setRoute(slot, routeInput.text.toString()); if (slot < 6) slot++; showSlot() }
        showSlot()

        label("Go convert when the bag is this full (%)")
        val bagInput = field(store.bagFullPct.toString(), number = true)
        label("Max farming time per round (minutes)")
        val farmInput = field(store.maxFarmMin.toString(), number = true)
        label("Max converting time (minutes)")
        val convInput = field(store.maxConvertMin.toString(), number = true)
        label("Zigzag: seconds forward/back per leg")
        val longInput = field(store.patternLong.toString(), decimal = true)
        label("Zigzag: seconds sideways per step")
        val sideInput = field(store.patternSide.toString(), decimal = true)
        label("Joystick push distance (% of screen height)")
        val joyInput = field((store.joyRadius * 100).toInt().toString(), number = true)
        label("Roblox app package")
        val pkgInput = field(store.robloxPkg)

        button("💾 Save settings") {
            store.hiveSlot = slot
            store.setRoute(slot, routeInput.text.toString())
            store.bagFullPct = bagInput.text.toString().toIntOrNull()?.coerceIn(10, 100) ?: 95
            store.maxFarmMin = farmInput.text.toString().toIntOrNull()?.coerceIn(1, 120) ?: 15
            store.maxConvertMin = convInput.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 8
            store.patternLong = longInput.text.toString().toFloatOrNull()?.coerceIn(0.2f, 10f) ?: 2f
            store.patternSide = sideInput.text.toString().toFloatOrNull()?.coerceIn(0.1f, 5f) ?: 0.6f
            store.joyRadius = (joyInput.text.toString().toIntOrNull()?.coerceIn(3, 30) ?: 10) / 100f
            store.robloxPkg = pkgInput.text.toString().trim().ifEmpty { "com.roblox.client" }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        label("Step 2 - in Roblox")
        TextView(this).apply {
            text = "Open Bee Swarm. A small Bee Macro panel appears on the left (drag it by its title).\n" +
                "1. Setup markers → drag the dots onto the buttons → Save\n" +
                "2. Bar % → should match your pollen bar\n" +
                "3. Test route → respawns and walks the route, so you can tune it\n" +
                "4. ▶ Start"
            textSize = 12f
        }.also { root.addView(it) }

        status = TextView(this).apply { setPadding(0, 32, 0, 0) }
        root.addView(status)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        store.setRoute(slot, routeInput.text.toString())
        store.hiveSlot = slot
    }

    private fun refresh() {
        val on = MacroService.instance != null
        val shots = Build.VERSION.SDK_INT >= 30
        status.text = "Macro service: " + (if (on) "ON" else "OFF - turn it on in step 1") +
            "\nReading the pollen bar: " + (if (shots) "supported" else "NOT supported (Android 10 or older) - uses timers")
    }
}
