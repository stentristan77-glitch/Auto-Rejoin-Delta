package com.beemacro

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private class StopSignal : Exception()

/**
 * The macro itself. Runs on its own thread:
 * Respawn (-> hive) -> Make Honey until the bar is empty -> route to the field -> farm until the bag is full -> repeat.
 */
class Engine(private val svc: MacroService) {

    @Volatile var running = false
    private val store = svc.store

    fun start(testRouteOnly: Boolean) {
        running = true
        svc.setRunningUi(true)
        Thread {
            var message = "Stopped"
            try {
                if (testRouteOnly) {
                    respawn()
                    svc.setStatus("Running route...")
                    runRoute(store.route())
                    message = "Route test done"
                } else {
                    mainLoop()
                }
            } catch (e: StopSignal) {
            } catch (e: Exception) {
                message = "Error: ${e.message}"
            } finally {
                running = false
                svc.setRunningUi(false)
                svc.setStatus(message)
            }
        }.start()
    }

    fun stop() { running = false }

    // ---------------------------------------------------------------- safety

    private fun robloxOnScreen(): Boolean {
        val fg = svc.foregroundPkg
        return fg.isEmpty() || fg == store.robloxPkg
    }

    /** Stops if asked to, and pauses while Roblox isn't on screen (so it never taps other apps). */
    private fun check() {
        if (!running) throw StopSignal()
        var told = false
        while (!robloxOnScreen()) {
            if (!running) throw StopSignal()
            if (!told) { svc.setStatus("Paused - open Roblox"); told = true }
            Thread.sleep(500)
        }
    }

    private fun sleep(ms: Long) {
        var left = ms
        while (left > 0) {
            check()
            val step = min(left, 100L)
            Thread.sleep(step)
            left -= step
        }
    }

    private fun now() = SystemClock.elapsedRealtime()

    // ---------------------------------------------------------------- touches

    private fun px(id: String): PointF {
        val size = svc.screenSize()
        val p = store.point(id)
        return PointF(p.x * size.x, p.y * size.y)
    }

    private fun tap(id: String) {
        check()
        val p = px(id)
        val path = Path().apply { moveTo(p.x, p.y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        svc.gesture(g, 60)
    }

    /**
     * Holds the joystick in a direction. angle: 0 = forward, 90 = right, 180 = back, 270 = left.
     * If jumpTap is true it also taps jump at the start (opens the glider when in the air).
     */
    private fun move(angle: Float, seconds: Float, jumpTap: Boolean) {
        check()
        val size = svc.screenSize()
        val c = px("JOY")
        val r = store.joyRadius * size.y
        val rad = Math.toRadians(angle.toDouble())
        val tx = (c.x + r * sin(rad)).toFloat()
        val ty = (c.y - r * cos(rad)).toFloat()

        // Press on the joystick and slide to the direction
        val first = Path().apply { moveTo(c.x, c.y); lineTo(tx, ty) }
        var stroke = GestureDescription.StrokeDescription(first, 0, 100, true)
        val b = GestureDescription.Builder().addStroke(stroke)
        if (jumpTap) {
            val j = px("JUMP")
            b.addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(j.x, j.y) }, 40, 60))
        }
        if (!svc.gesture(b.build(), 200)) return

        // Keep holding, in 1-second pieces so Stop reacts quickly
        var remaining = (seconds * 1000).toLong()
        var x = tx
        var wiggle = 1f
        var ok = true
        while (remaining > 0 && ok) {
            if (!running || !robloxOnScreen()) break
            val chunk = min(remaining, 1000L)
            remaining -= chunk
            val p = Path().apply { moveTo(x, ty); x += wiggle; wiggle = -wiggle; lineTo(x, ty) }
            stroke = stroke.continueStroke(p, 0, chunk, remaining > 0)
            ok = svc.gesture(GestureDescription.Builder().addStroke(stroke).build(), chunk)
        }
        if (remaining > 0 && ok) {
            // Stopped early: lift the finger
            try {
                val p = Path().apply { moveTo(x, ty); lineTo(x + 1f, ty) }
                stroke = stroke.continueStroke(p, 0, 20, false)
                svc.gesture(GestureDescription.Builder().addStroke(stroke).build(), 20)
            } catch (e: Exception) { }
        }
        check()
    }

    // ---------------------------------------------------------------- steps

    private fun pollen(): Float? = svc.pollenFraction()

    private fun respawn() {
        svc.setStatus("Respawning at hive...")
        tap("MENU"); sleep(1500)
        tap("RESPAWN"); sleep(1200)
        tap("CONFIRM"); sleep(7000)
    }

    private fun convert() {
        svc.setStatus("Making honey...")
        tap("ACTION"); sleep(2000)
        val start = now()
        val maxMs = store.maxConvertMin * 60_000L
        var lastF = pollen()
        var lastDrop = now()
        while (now() - start < maxMs) {
            sleep(3000)
            val f = pollen()
            if (f == null) {
                svc.setStatus("Making honey (timer, can't read bar)...")
                continue
            }
            svc.setStatus("Making honey... bag ${(f * 100).toInt()}%")
            if (f <= 0.02f) { sleep(1500); return }
            val prev = lastF
            if (prev != null && f < prev - 0.005f) lastDrop = now()
            if (now() - lastDrop > 15_000) {
                // Not going down - press Make Honey again
                tap("ACTION")
                lastDrop = now()
            }
            lastF = f
        }
    }

    private fun farm() {
        val start = now()
        val maxMs = store.maxFarmMin * 60_000L
        val l = store.patternLong
        val s = store.patternSide
        // Zigzag that ends where it started, so you don't drift out of the field
        val legs = listOf(0f to l, 90f to s, 180f to l, 90f to s, 0f to l, 270f to s, 180f to l, 270f to s)
        while (true) {
            for ((angle, secs) in legs) {
                move(angle, secs, false)
                val f = pollen()
                val pct = f?.let { (it * 100).toInt() }
                svc.setStatus("Farming... bag ${pct ?: "?"}%")
                if (pct != null && pct >= store.bagFullPct) return
                if (now() - start > maxMs) return
            }
        }
    }

    private fun runRoute(text: String) {
        for (raw in text.lines()) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val parts = line.split(Regex("\\s+"))
            val cmd = parts[0].lowercase()
            val a = parts.getOrNull(1)?.toFloatOrNull() ?: 0f
            val t = parts.getOrNull(2)?.toFloatOrNull() ?: 0f
            when (cmd) {
                "move" -> move(a, t, false)
                "glide" -> move(a, t, true)
                "jump" -> { tap("JUMP"); sleep(300) }
                "action" -> { tap("ACTION"); sleep(300) }
                "wait" -> sleep(((parts.getOrNull(1)?.toFloatOrNull() ?: 1f) * 1000).toLong())
                else -> svc.setStatus("Unknown route step: $line")
            }
        }
    }

    private fun mainLoop() {
        var round = 0
        while (true) {
            round++
            respawn()
            convert()
            svc.setStatus("Round $round: going to field...")
            runRoute(store.route())
            farm()
        }
    }
}
